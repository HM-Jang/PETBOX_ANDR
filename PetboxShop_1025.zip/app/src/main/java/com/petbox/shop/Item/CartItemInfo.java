package com.petbox.shop.Item;

/**
 * Created by petbox on 2015-09-17.
 */
public class CartItemInfo {
    public String imgUrl = ""; //상품 URL
    public String name = "";   //  이름 간략
    public String detail_name = "";    // Full 이름
    public int num = 0;   // 이전 페이지에서 신청한 상품 수
    public int max = 0;
    public int price = 0;  // 상품당 가격
}
