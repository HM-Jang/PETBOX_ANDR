package com.petbox.shop.Item;

/**
 * Created by petbox on 2015-10-14.
 */
public class OptionInfo{
    public int sno = 0; //옵션 번호?
    public String opt1 = "";    //옵션명
    public String opt2 = "";    //옵션2
    public int stock = 0;   //재고 : 9999
    public int price = 1;    // 가격
}