package com.petbox.shop.Delegate;

/**
 * Created by 펫박스 on 2015-10-11.
 */
public interface MyPageDelegate {
    public void setFragmentItem(int fragmentItem);
}
