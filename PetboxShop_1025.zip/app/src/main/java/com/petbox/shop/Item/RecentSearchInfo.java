package com.petbox.shop.Item;

/**
 * Created by petbox on 2015-09-16.
 */
public class RecentSearchInfo {
    public int rowId = 99999;
    public String title = "";
    public String date = "";

    public RecentSearchInfo(int _rowId, String _title, String _date){
        rowId = _rowId;
        title = _title;
        date = _date;
    }

}
