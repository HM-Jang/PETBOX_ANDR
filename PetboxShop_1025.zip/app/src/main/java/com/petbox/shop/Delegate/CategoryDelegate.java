package com.petbox.shop.Delegate;

/**
 * Created by petbox on 2015-10-01.
 */
public interface CategoryDelegate {
    //public void clickPlanning();
    //public void clickPrimium();
    public void clickCategoryGoods(int select);
    public void backCategory();
}
