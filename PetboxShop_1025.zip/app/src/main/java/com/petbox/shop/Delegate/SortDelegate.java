package com.petbox.shop.Delegate;

/**
 * Created by petbox on 2015-10-05.
 */
public interface SortDelegate {
    public void sort(int mode);
}
