package com.petbox.shop.Item;

/**
 * Created by petbox on 2015-09-16.
 */
public class PlanningItemInfo {

    public String name = "";
    public String linkaddr ="";
    public String loccd = "";
    public String img = "";

    public PlanningItemInfo(){}

    public PlanningItemInfo(String _name,String _linkaddr, String _loccd, String _img) {
        String name = _name;
        String linkaddr =_linkaddr;
        String loccd = _loccd;
        String img = _img;
    }
}
