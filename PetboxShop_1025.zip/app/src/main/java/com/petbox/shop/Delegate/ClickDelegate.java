package com.petbox.shop.Delegate;

/**
 * Created by petbox on 2015-10-17.
 */
public interface ClickDelegate {
    public void click(int position);
    public void click(int position, int depth);
}
