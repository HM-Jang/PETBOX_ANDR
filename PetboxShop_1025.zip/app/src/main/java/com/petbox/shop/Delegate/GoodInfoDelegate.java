package com.petbox.shop.Delegate;

/**
 * Created by petbox on 2015-10-12.
 */
public interface GoodInfoDelegate {
    public void refreshAllPrice();
}
