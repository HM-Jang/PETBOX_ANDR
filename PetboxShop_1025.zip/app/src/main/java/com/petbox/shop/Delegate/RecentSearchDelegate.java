package com.petbox.shop.Delegate;

/**
 * Created by petbox on 2015-09-21.
 */
public interface RecentSearchDelegate {
    public void deleteNRefresh(int rowId);
}
