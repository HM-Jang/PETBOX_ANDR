package com.petbox.shop.Item;

/**
 * Created by petbox on 2015-10-14.
 */
public class AddOptionInfo{
    public int sno = 0; //추가옵션 번호
    public int step = 0; // 추가옵션 그룹 번호
    public String opt = "";    // 추가옵션명
    public int addprice = 0; // 추가옵션 개당 가격
    public String optionName = "";  // 해당 옵션의 부모 이름
}