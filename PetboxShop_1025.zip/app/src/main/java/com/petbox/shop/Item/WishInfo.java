package com.petbox.shop.Item;

/**
 * Created by Seo on 2015-10-14.
 */
public class WishInfo {
    public String goodsno="";
    public String opt1="";
    public String opt2="";
    public String addopt="";
    public String img_i="";
    public String goodsnm="";
    public String goods_consumer="";
    public String goods_price="";
    public String icon="";
    public String point="";
    public String point_count="";


    public WishInfo(String _goodsno, String _opt1, String _opt2, String _addopt, String _img_i, String _goodsnm, String _goods_consumer, String _goods_price, String _icon, String _point, String _point_count) {
        String goodsno = _goodsno;
        String opt1 = _opt1;
        String opt2 = _opt2;
        String addopt = _addopt;
        String img_i = _img_i;
        String goodsnm = _goodsnm;
        String goods_consumer = _goods_consumer;
        String goods_price = _goods_price;
        String icon = _icon;
        String point = _point;
        String point_count = _point_count;
    }
}
