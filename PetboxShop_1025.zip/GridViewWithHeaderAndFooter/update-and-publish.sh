python update-project.py
./gradlew clean :uploadArchives
