# Changelog

## 1.0.6 2014-11-21

* Make it can run in 2.3, fix [#3](https://github.com/liaohuqiu/android-GridViewWithHeaderAndFooter/issues/3), [#4](https://github.com/liaohuqiu/android-GridViewWithHeaderAndFooter/issues/4)

## 1.0.7

1.0.8 should be this release. But I wrote an improper version code. :)

## 1.0.8 2014-11-24

* Make it display correctly when API level < 11
* Make reuse working correctly, fix [#2](https://github.com/liaohuqiu/android-GridViewWithHeaderAndFooter/issues/2)
* Make header layout full width even when gravity set to `center`, fix [#5](https://github.com/liaohuqiu/android-GridViewWithHeaderAndFooter/issues/5)
